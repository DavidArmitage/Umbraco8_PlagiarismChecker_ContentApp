﻿
angular.module("umbraco")
    .controller("My.PlagiarismChecker", function ($http, $scope, editorState, contentResource) {

        var vm = this;
        vm.IsTestMode = false;
        vm.Loading = false;
        vm.ShowResults = false;
        vm.ErrorMessage = '';
        vm.CurrentNodeId = editorState.current.id;
        vm.CurrentNodeAlias = editorState.current.contentTypeAlias;
        vm.FullContent = '';
        vm.EditorState = editorState;

        $http({
            method: "GET",
            url: "/Umbraco/PlagiarismChecker/PlagiarismChecker/IsTestMode"
        }).then(function mySuccess(response) {
            vm.IsTestMode = response.data;
        });

        $scope.Analyse = function () {
            vm.FullContent = '';
            var currentPage = contentResource.getById(vm.CurrentNodeId).then(function (node) {

                var editorState = vm.EditorState.current;
                var variants = editorState.variants;
                if (variants) {
                    var variantIndex;
                    for (variantIndex = 0; variantIndex < variants.length; ++variantIndex) {
                        if (variants[variantIndex].active == true) {
                            var tabs = variants[variantIndex].tabs;
                            if (tabs) {
                                var tabIndex;
                                for (tabIndex = 0; tabIndex < tabs.length; ++tabIndex) {
                                    var properties = node.variants[variantIndex].tabs[tabIndex].properties;
                                    var propertyIndex;
                                    for (propertyIndex = 0; propertyIndex < properties.length; ++propertyIndex) {
                                        if (properties[propertyIndex].editor == "Umbraco.Grid") {
                                            var gridWords = $scope.UmbracoGridExtract(properties[propertyIndex]);
                                            vm.FullContent = vm.FullContent + gridWords;
                                        }
                                        else {
                                            var words = properties[propertyIndex].value + ' ';
                                            vm.FullContent = vm.FullContent + words;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                vm.Loading = true;
                vm.ShowResults = false;
                vm.ErrorMessage = '';
                var url = "/Umbraco/PlagiarismChecker/PlagiarismChecker/Analyse";

                $http({
                    method: "POST",
                    url: url,
                    data: { TextToCompare: vm.FullContent },
                }).then(function successCallback(response) {
                    var data = angular.fromJson(response.data);

                    if (data.Success == false) {
                        vm.Loading = false;
                        vm.ErrorMessage = data.ErrorMessage;
                    }
                    else {
                        vm.Loading = false;
                        vm.MatchCount = data.MatchCount;
                        vm.Querywords = data.Querywords;
                        vm.Cost = data.Cost;
                        vm.ViewAllUrl = data.ViewAllUrl;
                        vm.Matches = data.Matches;
                        vm.ShowResults = true;
                    }
                }, function errorCallback() {
                    vm.Loading = false;
                    vm.ErrorMessage = "Sorry there was a generic error. If this continues to happen please notify support for a fix.";
                });
            });
        };

        $scope.UmbracoGridExtract = function (property) {

            var sectionIndex;
            var sections = property.value.sections;
            var gridContent = '';

            for (sectionIndex = 0; sectionIndex < sections.length; ++sectionIndex) {
                var rowsIndex;
                var rows = property.value.sections[sectionIndex].rows;

                for (rowsIndex = 0; rowsIndex < rows.length; ++rowsIndex) {
                    var areasIndex;
                    var areas = property.value.sections[sectionIndex].rows[rowsIndex].areas;

                    for (areasIndex = 0; areasIndex < areas.length; ++areasIndex) {
                        var controlsIndex;
                        var controls = property.value.sections[sectionIndex].rows[rowsIndex].areas[areasIndex].controls;

                        for (controlsIndex = 0; controlsIndex < controls.length; ++controlsIndex) {
                            var value = property.value.sections[sectionIndex].rows[rowsIndex].areas[areasIndex].controls[controlsIndex].value;
                            gridContent = gridContent + " " + value;
                        }
                    }
                }
            }

            return gridContent;
        };
    });
